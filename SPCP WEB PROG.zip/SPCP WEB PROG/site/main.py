from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/4090.html')
def video():
    return render_template('4090.html')

@app.route('/gigabyte.html')
def mater():
    return render_template('gigabyte.html')

@app.route('/intel.html')
def proc():
    return render_template('intel.html')

app.run(debug=True)